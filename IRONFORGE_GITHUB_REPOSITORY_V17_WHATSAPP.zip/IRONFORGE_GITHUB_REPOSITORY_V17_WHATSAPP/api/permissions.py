from rest_framework.permissions import BasePermission

class IsAdminUser(BasePermission):
    message = "Admin access required."
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)

class IsCoach(BasePermission):
    message = "Coach access required."
    def has_permission(self, request, view):
        return bool(
            request.user and request.user.is_authenticated and
            hasattr(request.user, "coach") and request.user.coach.active
        )
